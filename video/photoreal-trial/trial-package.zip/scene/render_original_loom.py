import bpy,hashlib,json
from pathlib import Path
from mathutils import Vector
ROOT=Path('/workspace/kesi-photoreal-trial');OUT=ROOT/'output';source=Path('/workspace/attachments/7cc6e5b5-1fd5-46b8-b7bf-bd27a2934f4e/kesi_loom_peony.glb')
expected='23caa52aaa02af6f9a0bd81529e7498821263cc11b89b83ba6d16397a1b2e8bd';assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(source));originals=list(bpy.context.selected_objects)
for o in originals:
 if o.animation_data:o.animation_data_clear()
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False
scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.world.color=(.22,.22,.20)
def mat(name,col):
 m=bpy.data.materials.new(name);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*col,1);bs.inputs['Roughness'].default_value=.90;return m
floor_mat=mat('Neutral warm studio ground',(.53,.46,.35))
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.025));bpy.context.object.name='Independent studio floor';bpy.context.object.data.materials.append(floor_mat)
def area(name,loc,power,size):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
area('Large soft daylight',(-3,2,5),650,4);area('Warm soft fill',(3,-2,3),300,4)
d=bpy.data.cameras.new('Original loom reference camera');cam=bpy.data.objects.new('Original loom reference camera',d);bpy.context.collection.objects.link(cam);scene.camera=cam
corners=[o.matrix_world@Vector(p)for o in originals if o.type=='MESH'for p in o.bound_box]
low=Vector(tuple(min(p[i]for p in corners)for i in range(3)));high=Vector(tuple(max(p[i]for p in corners)for i in range(3)));target=(low+high)/2
cam.location=target+Vector((-3.0,3.95,1.5));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO'
q=cam.rotation_euler.to_quaternion();right=q@Vector((1,0,0));up=q@Vector((0,1,0));w=max(p.dot(right)for p in corners)-min(p.dot(right)for p in corners);h=max(p.dot(up)for p in corners)-min(p.dot(up)for p in corners);d.ortho_scale=max(w,h*16/9)*1.12
scene.view_layers[0].use_pass_z=True;scene.use_nodes=True;nt=scene.node_tree;nt.nodes.clear();layers=nt.nodes.new('CompositorNodeRLayers');comp=nt.nodes.new('CompositorNodeComposite');nt.links.new(layers.outputs['Image'],comp.inputs['Image']);f=nt.nodes.new('CompositorNodeOutputFile');f.base_path=str(OUT);f.file_slots[0].path='loom-depth-';f.format.file_format='OPEN_EXR';f.format.color_depth='32';nt.links.new(layers.outputs['Depth'],f.inputs[0])
scene.render.image_settings.file_format='PNG';scene.render.filepath=str(OUT/'original-loom-base.png');bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'original-loom-scene.blend'));bpy.ops.render.render(write_still=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
(OUT/'original-loom-check.json').write_text(json.dumps({'source':str(source),'source_sha256':expected,'source_edited':False,'imported_meshes':sum(o.type=='MESH'for o in originals),'original_materials_replaced':False,'notes':'Background render and depth pass are separate from the AI character image; no completed human/loom composite or video is claimed.'},indent=2))
print('ORIGINAL LOOM RENDER COMPLETE',flush=True)
